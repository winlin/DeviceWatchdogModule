/** Automatically generated file. DO NOT MODIFY */
package com.example.posjnitest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}